import java.util.ArrayList;

public class Inventario {
    private ArrayList<Repuesto> repuestos;

    public Inventario() {
        this.repuestos = new ArrayList<>();
    }

    public void agregarRepuesto(Repuesto repuesto) {
        repuestos.add(repuesto);
    }

    public void eliminarRepuesto(String codigo) {
        Repuesto repuestoAEliminar = buscarRepuesto(codigo);
        if (repuestoAEliminar != null) {
            repuestos.remove(repuestoAEliminar);
        }
    }

    public void modificarRepuesto(String codigo, String nuevoNombre, String nuevaCategoria, double nuevoPrecio, int nuevoStock) {
        Repuesto repuesto = buscarRepuesto(codigo);
        if (repuesto != null) {
            repuesto.setNombre(nuevoNombre);
            repuesto.setCategoria(nuevaCategoria);
            repuesto.setPrecio(nuevoPrecio);
            repuesto.setStock(nuevoStock);
        }
    }

    public Repuesto buscarRepuesto(String codigo) {
        for (Repuesto repuesto : repuestos) {
            if (repuesto.getCodigo().equals(codigo)) {
                return repuesto;
            }
        }
        return null;
    }

    public String mostrarRepuestos() {
        StringBuilder builder = new StringBuilder();
        if (repuestos.isEmpty()) {
            builder.append("No hay repuestos en el inventario.\n");
        } else {
            for (Repuesto repuesto : repuestos) {
                builder.append(repuesto.mostrarInformacion()).append("\n-------------------------\n");
            }
        }
        return builder.toString();
    }
}
