import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        Inventario inventario = new Inventario();
        int opcion;

        do {
            // Menú de opciones
            String menu = "Menú de Opciones:\n" +
                    "1. Agregar repuesto\n" +
                    "2. Modificar repuesto\n" +
                    "3. Eliminar repuesto\n" +
                    "4. Ver inventario\n" +
                    "5. Buscar repuesto por código\n" +
                    "6. Salir\n" +
                    "Seleccione una opción:";
            String input = JOptionPane.showInputDialog(menu);

            if (input == null) break; // En caso de cancelar
            opcion = Integer.parseInt(input);

            switch (opcion) {
                case 1:
                    // Agregar repuesto
                    String codigo = JOptionPane.showInputDialog("Ingrese el código del repuesto:");
                    String nombre = JOptionPane.showInputDialog("Ingrese el nombre del repuesto:");
                    String categoria = JOptionPane.showInputDialog("Ingrese la categoría del repuesto:");
                    double precio = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el precio del repuesto:"));
                    int stock = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el stock del repuesto:"));
                    Repuesto repuesto = new Repuesto(codigo, nombre, categoria, precio, stock);
                    inventario.agregarRepuesto(repuesto);
                    JOptionPane.showMessageDialog(null, "Repuesto agregado con éxito.");
                    break;

                case 2:
                    // Modificar repuesto
                    codigo = JOptionPane.showInputDialog("Ingrese el código del repuesto a modificar:");
                    Repuesto repuestoAModificar = inventario.buscarRepuesto(codigo);
                    if (repuestoAModificar != null) {
                        nombre = JOptionPane.showInputDialog("Ingrese el nuevo nombre:", repuestoAModificar.getNombre());
                        categoria = JOptionPane.showInputDialog("Ingrese la nueva categoría:", repuestoAModificar.getCategoria());
                        precio = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el nuevo precio:", repuestoAModificar.getPrecio()));
                        stock = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el nuevo stock:", repuestoAModificar.getStock()));
                        inventario.modificarRepuesto(codigo, nombre, categoria, precio, stock);
                        JOptionPane.showMessageDialog(null, "Repuesto modificado con éxito.");
                    } else {
                        JOptionPane.showMessageDialog(null, "Repuesto no encontrado.");
                    }
                    break;

                case 3:
                    // Eliminar repuesto
                    codigo = JOptionPane.showInputDialog("Ingrese el código del repuesto a eliminar:");
                    inventario.eliminarRepuesto(codigo);
                    JOptionPane.showMessageDialog(null, "Repuesto eliminado.");
                    break;

                case 4:
                    // Ver inventario
                    String inventarioText = inventario.mostrarRepuestos();
                    JOptionPane.showMessageDialog(null, inventarioText);
                    break;

                case 5:
                    // Buscar repuesto por código
                    codigo = JOptionPane.showInputDialog("Ingrese el código del repuesto:");
                    Repuesto repuestoBuscado = inventario.buscarRepuesto(codigo);
                    if (repuestoBuscado != null) {
                        JOptionPane.showMessageDialog(null, repuestoBuscado.mostrarInformacion());
                    } else {
                        JOptionPane.showMessageDialog(null, "Repuesto no encontrado.");
                    }
                    break;

                case 6:
                    JOptionPane.showMessageDialog(null, "Saliendo del sistema...");
                    break;

                default:
                    JOptionPane.showMessageDialog(null, "Opción no válida.");
            }
        } while (opcion != 6);
    }
}
